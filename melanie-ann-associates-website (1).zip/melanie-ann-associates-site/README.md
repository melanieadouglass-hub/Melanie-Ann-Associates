# Melanie Ann & Associates — Website

A clean, luxury-minimal static website (6 pages) designed to be **easy to edit**.

## Pages
- `index.html` (Home)
- `about.html`
- `services.html`
- `membership.html`
- `learning-center.html`
- `contact.html`

## How to run locally
1. Download the folder.
2. Open `index.html` in your browser.

## How to edit
- Open any `.html` file in a text editor.
- Shared styles are in `assets/styles.css`.
- Minimal behavior (nav + scroll reveal) in `assets/site.js`.

### Fast edits
- Brand name + tagline are in the header/footer of each page.
- Colors are CSS variables at the top of `assets/styles.css`.
- Replace placeholder booking/social links in `contact.html`.
- Connect forms to Mailchimp/ConvertKit/etc. by replacing the `<form>` tags' `action` and `method`.

## SEO
- Each page has a title, meta description, and keyword set.
- Update the Open Graph URL fields if you have a domain.
