// Melanie Ann & Associates — minimal JS for nav + reveal animations

(function(){
  const btn = document.querySelector('[data-menu]');
  const nav = document.querySelector('[data-nav]');
  if(btn && nav){
    btn.addEventListener('click', () => nav.classList.toggle('open'));
  }

  const items = document.querySelectorAll('.reveal');
  if('IntersectionObserver' in window && items.length){
    const obs = new IntersectionObserver((entries)=>{
      entries.forEach(e=>{
        if(e.isIntersecting){
          e.target.classList.add('is-visible');
          obs.unobserve(e.target);
        }
      })
    }, {threshold: 0.12});
    items.forEach(el=>obs.observe(el));
  } else {
    items.forEach(el=>el.classList.add('is-visible'));
  }
})();
